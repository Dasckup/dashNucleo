<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CommentsEditorsProccessUpload extends Model
{
    use HasFactory;

    protected $table = 'comments_editors_proccess_upload';
}

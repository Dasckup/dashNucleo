<?php
namespace App\Http\Middleware;


class AWS{
    public function __construct()
    {
    }
}

<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Clients\ClientsController as Clients;
use App\Http\Controllers\Home\HomeController as Home;
use App\Http\Controllers\Login\LoginController as Login;
use App\Http\Controllers\User\UserController as Users;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::controller(Login::class)->group(function (){
    Route::get('/login', 'index')->name("login.index");
    Route::post('/login', 'store')->name("login.store");
    Route::get('/logout', 'destroy')->name("login.destroy");
});

Route::middleware(['auth'])->group(function () {

    Route::get('/', [Home::class, 'index'])->name("home");

    Route::controller(Clients::class)->group(function () {
        Route::get('/clientes', 'index')->name("client.index");
        Route::get('/clientes/{id}/{status}', 'update')->name("client.update");
        Route::get('/clientes/{id}/', 'show')->name("client.show");
    });

    Route::controller(Users::class)->group(function (){
        Route::get('/perfil', 'show')->name("user.show");
    });

});


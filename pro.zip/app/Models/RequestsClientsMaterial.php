<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RequestsClientsMaterial extends Model
{
    use HasFactory;

    protected $table = "requests_clients_material";
}

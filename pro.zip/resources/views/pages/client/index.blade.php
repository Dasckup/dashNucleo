@extends('main._index')

@section('css')
@endsection

@section('js')
    <script src="{{asset("/template/assets/js/datatables.js")}}"></script>
@endsection

@section('content')
    <div class="app-content">
        <div class="content-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="page-description">
                            <h1>Clientes</h1>
                            <span>Encontre detalhes importantes de contato e perfis de forma eficiente.</span>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="card">
                            <div class="card-body">
                                <table id="datatable1" class="display" style="width:100%">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Clientes</th>
                                        <th>Produto/Prazo</th>
                                        <th>Status</th>
                                        <th>Contato</th>
                                        <th>Criado</th>
                                        <th>Ações</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($clients as $client)
                                            <tr>
                                                <td>{{$client->id}}</td>
                                                <td>
                                                    <div class="d-flex align-items-center">

                                                        <div>
                                                            <p class="m-0 title-row-in-table">{{$client->name}} {{$client->lastname}}</p>
                                                            <p class="m-0 sub-title-row-in-table">@if(isset($client->submission)){{$client->submission->find_us}}@endif</p>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    @if($client->submission)
                                                    <div class="d-flex align-items-center">
                                                        <div>
                                                            <p class="m-0 title-row-in-table">
                                                                {{$client->submission->term_publication_title}}
                                                            </p>
                                                            <p class="m-0 sub-title-row-in-table d-flex align-items-center">
                                                                {{$client->submission->term_publication_price}}
                                                                @if(!str_contains($client->submission->term_publication_price,"R$"))
                                                                    <img src="{{asset("/template/assets/images/icons/united-states.png")}}" style=" width: 16px; margin-left: 3px; " alt="">
                                                                @endif
                                                            </p>
                                                        </div>
                                                    </div>
                                                    @endif
                                                </td>
                                                <td>
                                                    <div class="dropdown">
                                                        <a style=" font-size: 13px; text-transform: uppercase;font-weight: 600" class="btn border-2 bg-transparent text-@if($client->status){{$client->status->bs}}@endif border-@if($client->status){{$client->status->bs}}@endif dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                                                            @if($client->status){{$client->status->status}}@endif
                                                        </a>

                                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                            <li><a class="dropdown-item d-flex align-items-center text-warning" href="{{route("client.update", ["id"=>$client->id,"status"=>"pendente"])}}">
                                                            <i class="material-icons me-2" style="font-size: 19px">schedule</i> Pendente
                                                            </a></li>
                                                            <li><a class="dropdown-item d-flex align-items-center text-success" href="{{route("client.update", ["id"=>$client->id,"status"=>"atendido"])}}">
                                                            <i class="material-icons me-2" style="font-size: 19px">done</i> Atendido
                                                            </a></li>
                                                            <li><a class="dropdown-item d-flex text-danger align-items-center" href="{{route("client.update", ["id"=>$client->id,"status"=>"excluido"])}}">
                                                            <i class="material-icons me-2" style="font-size: 19px">delete</i> Excluido
                                                            </a></li>
                                                        </ul>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <div>
                                                            <p class="m-0 title-row-in-table">{{$client->email}}</p>
                                                            <p class="m-0 sub-title-row-in-table">{{$client->ddi}} {{$client->cellphone}}</p>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>{{date("d/m/Y \á\s H:i", strtotime($client->created_at))}}</td>
                                                <td>
                                                    <a href="{{route("client.show", ["id"=>$client->id])}}">Ver mais</a>
                                                </td>
                                            </tr>
                                        @endforeach



                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@extends('main._index')

@section('css')
@endsection

@section('js')
@endsection

@section('content')
    <div class="app-content">
        <div class="content-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="page-description">
                            <h1>Dashboard</h1>
                            <span>Os relatórios apareceram aqui em breve... </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

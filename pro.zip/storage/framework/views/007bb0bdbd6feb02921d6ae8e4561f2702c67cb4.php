<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("/template/assets/js/datatables.js")); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="app-content">
        <div class="content-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="page-description">
                            <h1>Clientes</h1>
                            <span>Encontre detalhes importantes de contato e perfis de forma eficiente.</span>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="card">
                            <div class="card-body">
                                <table id="datatable1" class="display" style="width:100%">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Clientes</th>
                                        <th>Produto/Prazo</th>
                                        <th>Status</th>
                                        <th>Contato</th>
                                        <th>Criado</th>
                                        <th>Ações</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($client->id); ?></td>
                                                <td>
                                                    <div class="d-flex align-items-center">

                                                        <div>
                                                            <p class="m-0 title-row-in-table"><?php echo e($client->name); ?> <?php echo e($client->lastname); ?></p>
                                                            <p class="m-0 sub-title-row-in-table"><?php if(isset($client->submission)): ?><?php echo e($client->submission->find_us); ?><?php endif; ?></p>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <?php if($client->submission): ?>
                                                    <div class="d-flex align-items-center">
                                                        <div>
                                                            <p class="m-0 title-row-in-table">
                                                                <?php echo e($client->submission->term_publication_title); ?>

                                                            </p>
                                                            <p class="m-0 sub-title-row-in-table d-flex align-items-center">
                                                                <?php echo e($client->submission->term_publication_price); ?>

                                                                <?php if(!str_contains($client->submission->term_publication_price,"R$")): ?>
                                                                    <img src="<?php echo e(asset("/template/assets/images/icons/united-states.png")); ?>" style=" width: 16px; margin-left: 3px; " alt="">
                                                                <?php endif; ?>
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <div class="dropdown">
                                                        <a style=" font-size: 13px; text-transform: uppercase;font-weight: 600" class="btn border-2 bg-transparent text-<?php if($client->status): ?><?php echo e($client->status->bs); ?><?php endif; ?> border-<?php if($client->status): ?><?php echo e($client->status->bs); ?><?php endif; ?> dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                                                            <?php if($client->status): ?><?php echo e($client->status->status); ?><?php endif; ?>
                                                        </a>

                                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                            <li><a class="dropdown-item d-flex align-items-center text-warning" href="<?php echo e(route("client.update", ["id"=>$client->id,"status"=>"pendente"])); ?>">
                                                            <i class="material-icons me-2" style="font-size: 19px">schedule</i> Pendente
                                                            </a></li>
                                                            <li><a class="dropdown-item d-flex align-items-center text-success" href="<?php echo e(route("client.update", ["id"=>$client->id,"status"=>"atendido"])); ?>">
                                                            <i class="material-icons me-2" style="font-size: 19px">done</i> Atendido
                                                            </a></li>
                                                            <li><a class="dropdown-item d-flex text-danger align-items-center" href="<?php echo e(route("client.update", ["id"=>$client->id,"status"=>"excluido"])); ?>">
                                                            <i class="material-icons me-2" style="font-size: 19px">delete</i> Excluido
                                                            </a></li>
                                                        </ul>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <div>
                                                            <p class="m-0 title-row-in-table"><?php echo e($client->email); ?></p>
                                                            <p class="m-0 sub-title-row-in-table"><?php echo e($client->ddi); ?> <?php echo e($client->cellphone); ?></p>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td><?php echo e(date("d/m/Y \á\s H:i", strtotime($client->created_at))); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route("client.show", ["id"=>$client->id])); ?>">Ver mais</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main._index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\project-laravel-nucleo\nucleodashboard\resources\views/pages/client/index.blade.php ENDPATH**/ ?>
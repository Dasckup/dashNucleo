
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Responsive Admin Dashboard Template">
    <meta name="keywords" content="admin,dashboard">
    <meta name="author" content="stacks">
    <link rel="icon" href="<?php echo e(asset("/template/assets/images/icons/logo_favicon.ico")); ?>" />
    <!-- The above 6 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>Dasckup & Núcleo do Conhecimento</title>

    <!-- Styles -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp" rel="stylesheet">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset("/template/assets/css/plugin.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("/template/assets/css/theme.css")); ?>">
</head>

    <body>
    <div class="app horizontal-menu app-auth-sign-in align-content-stretch d-flex flex-wrap justify-content-end">
        <div class="app-auth-background">

        </div>
        <div class="app-auth-container position-relative">
            <div class="logo" >
                <a style="background-image: initial;font-size: 25px;padding: 0px" >Dasckup <br/>& Núcleo Conheimento</a>
            </div>
            <p class="auth-description">Este é um dashboard desevolvido pela <a target="_blank" href="https://dasckup.com">Dasckup</a> em parceria a
                <a target="_blank" href="https://nucleodoconhecimento.com.br">Revista Núcleo do Conhecimento</a> </p>

            <form method="POST" action="<?php echo e(route("login.store")); ?>">
            <?php echo csrf_field(); ?>
            <div class="auth-credentials m-b-xxl">
                <div class="position-relative">
                    <label for="signInEmail" class="form-label">E-mail</label>
                    <input name="email" type="text" class="form-control m-b-md <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="signInEmail" aria-describedby="signInEmail" placeholder="exemplo@dasckup.com">
                    <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-tooltip">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="position-relative">
                    <label for="signInPassword" class="form-label">Senha</label>
                    <input name="password" type="password" class="form-control <?php $__errorArgs = ["password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="signInPassword" aria-describedby="signInPassword" placeholder="&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;">
                    <?php $__errorArgs = ["password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-tooltip">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="auth-submit">
                <button type="submit" class="btn btn-primary">Login</button>
            </div>
            </form>
            <div class="w-100 d-flex flex-column align-items-center" style="position: absolute;bottom: 0;left: 0">
                <span>Desolvido com 💖 por <a class="ms-2" href="https://dasckup.com">Dasckup</a></span>
                <p style="color: #666;font-size: 11px">Soluções a 1 clique de distância</p>
            </div>
        </div>
    </div>

    </body>
</html>
<script src="<?php echo e(asset("/template/assets/js/plugin.js")); ?>"></script>
<script src="<?php echo e(asset("/template/assets/js/theme.js")); ?>"></script>
<?php /**PATH C:\projects\project-laravel-nucleo\nucleodashboard\resources\views/pages/login/index.blade.php ENDPATH**/ ?>
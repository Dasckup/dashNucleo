
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Responsive Admin Dashboard Template">
    <meta name="keywords" content="admin,dashboard">
    <meta name="author" content="stacks">
    <link rel="icon" href="<?php echo e(asset("/template/assets/images/icons/logo_favicon.ico")); ?>" />

    <!-- Title -->
    <title>Dasckup & Nucleo do Conhecimento</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp" rel="stylesheet">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset("/template/assets/css/plugin.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("/template/assets/css/theme.css")); ?>">
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>

<div class="app horizontal-menu align-content-stretch d-flex flex-wrap">
    <div class="app-container">
        <?php echo $__env->make('main.Header.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('main.Footer.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>


</body>
</html>

<script src="<?php echo e(asset("/template/assets/js/plugin.js")); ?>"></script>
<script src="<?php echo e(asset("/template/assets/js/theme.js")); ?>"></script>

<?php echo $__env->yieldContent('js'); ?>
<?php /**PATH C:\projects\project-laravel-nucleo\nucleodashboard\resources\views/main/_index.blade.php ENDPATH**/ ?>
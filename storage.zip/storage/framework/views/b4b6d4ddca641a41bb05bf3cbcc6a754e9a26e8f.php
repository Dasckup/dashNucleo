<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-content">
    <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="page-description">
                        <h1>Meu perfil</h1>
                        <span>Aqui você pode editar suas informações</span>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="col-sm-8">
                                <form action="">
                                    <div class="row mb-4">
                                        <div class="col-md-6">
                                            <label for="name" class="form-label">Nome <code>*</code></label>
                                            <input value="<?php echo e($user["name"]); ?>" type="text" class="form-control" id="name" name="name" placeholder="John">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="email" class="form-label">E-mail <code>*</code></label>
                                            <input value="<?php echo e($user["email"]); ?>" type="email" class="form-control" name="email" id="email" placeholder="examplo@exemplo.com">
                                            <div id="settingsEmailHelp" class="form-text">O e-mail deve ser válido</div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label for="password" class="form-label">Senha <code>*</code></label>
                                            <input type="password" class="form-control" id="password" name="password" placeholder="John">
                                            <div class="form-text">Preencha este campo caso deseje alterar sua senha</div>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="confirm-password" class="form-label">Confirmar Senha <code>*</code></label>
                                            <input type="password" class="form-control" name="confirm-password" id="confirm-password" placeholder="examplo@exemplo.com">
                                            <div class="form-text">As senhas devem ser identicas</div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('authors.main._index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\project-laravel-nucleo\nucleodashboard\resources\views/authors/pages/user/show.blade.php ENDPATH**/ ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset("/template/assets/js/datatables.js")); ?>"></script>

    <script>
        $(document).ready(function() {
            $('#myMaterials').DataTable({
                "language": {
                    "sZeroRecords": "<?= __('messages.datatable.sZeroRecords') ?>",
                    "paginate": {
                        "next": ">",
                        "previous": "<"
                    },
                    "info": "<?= __('messages.datatable.showing') ?> _START_ <?= __('messages.datatable.to') ?> _END_ <?= __('messages.datatable.of') ?> _TOTAL_",
                    "sInfoEmpty": "<?= __('messages.datatable.showing') ?> 0 <?= __('messages.datatable.to') ?> 0 <?= __('messages.datatable.of') ?> 0",
                    "infoFiltered": "(<?= __('messages.datatable.filtered_from') ?> _MAX_)",
                    "decimal": ",",
                    "thousands": ".",
                    "lengthMenu": "<?= __('messages.datatable.showing') ?> _MENU_",
                    "search": "<?= __('messages.datatable.search') ?>:"
                },
                "order": [[0, "desc"]]
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="app-content">
        <div class="content-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-description">
                            <h1><?php echo e(__('messages.home.title_my_materials')); ?></h1>
                            <span><?php echo e(__('messages.home.subtitle_my_materials')); ?></span>
                        </div>
                    </div>
                    <div class="col-sm-12 card">
                        <div class="card-body">
                            <table id="myMaterials" class="display table align-middle  table-bordered border-primary" style="width:100%">
                                <thead>
                                <tr>
                                    <th style="width:0%;" class="text-center d-none">#</th>
                                    <th style="width:19%">Produto/Prazo</th>
                                    <th style="width:15%" >data de submissão</th>
                                    <th style="width:13%" class="text-center">Ações</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $clientSubmissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $name = explode(' ', mb_convert_case($client->name, MB_CASE_TITLE, "UTF-8"))[0];
                                            $email = $client->email != null? $client->email : "Não informado";
                                        ?>
                                        <tr>
                                            <td class="d-none"><?php echo e($client->id); ?></td>
                                            <td>
                                                <?php if($client->submission): ?>
                                                <div class="d-flex align-items-center">
                                                    <div>
                                                        <p class="m-0 text-black title-row-in-table">
                                                            <?php echo e($client->submission->term_publication_title); ?>

                                                        </p>
                                                        <p style="font-weight:500" class="m-0 sub-title-row-in-table d-flex align-items-center">
                                                            <?php if(!str_contains($client->submission->term_publication_price,"BRL")): ?>
                                                                <i title="internacional" class="material-icons text-gray" style=" font-size: 16px; margin-right:4px">public</i>
                                                            <?php endif; ?>
                                                            <?php echo e($client->submission->term_publication_price); ?>

                                                        </p>
                                                    </div>
                                                </div>
                                                <?php endif; ?>
                                            </td>
                                            <td class="">
                                                <div class="d-flex align-items-center">
                                                    <div>
                                                        <p class="m-0 text-black title-row-in-table"><?php echo e(date("d/m/Y", strtotime($client->created_at))); ?></p>
                                                        <p style="font-weight:500" class="m-0 sub-title-row-in-table"><?php echo e(date("\á\s H:i", strtotime($client->created_at))); ?></p>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="text-center">
                                                <a href="<?php echo e(route("client.show", ["id"=>$client->id])); ?>">VER MAIS</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('authors.main._index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\project-laravel-nucleo\nucleodashboard\resources\views/authors/pages/home/index.blade.php ENDPATH**/ ?>